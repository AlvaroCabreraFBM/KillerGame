package killergame;

public class Autonomous extends Alive {

    // Attributes
    
    // Constructors
    public Autonomous(KillerGame game, int posX, int posY, String type, int red, int green, int blue, int velX, int velY) {
        super(game, posX, posY, type, red, green, blue, velX, velY);
    }

    public Autonomous() {
    }

    // Methods
    
    // Main activity
    
}
