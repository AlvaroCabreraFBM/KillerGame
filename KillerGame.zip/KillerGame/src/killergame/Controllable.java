package killergame;

public class Controllable extends Alive {

    // Attributes
    
    // Constructor
    public Controllable(KillerGame game, int posX, int posY, String type, int red, int green, int blue, int velX, int velY) {
        super(game, posX, posY, type, red, green, blue, velX, velY);
    }

    public Controllable() {
    }

    // Methods
    
    // Main activity
    
}
